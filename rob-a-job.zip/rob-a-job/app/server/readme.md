
### Install dependencies
```
npm install
```

### Starting the server (localhost:3001)
```
npm start
```
